// Package shared 定义主控与被控之间的协议数据结构
package shared

const ProtocolVersion = 1

// WebSocket 消息类型常量
const (
	MsgTypeHello       = "hello"        // 被控 → 主控:首次连接,自报家门
	MsgTypeHelloAck    = "hello_ack"    // 主控 → 被控:接受连接,下发节点 ID
	MsgTypeMetric      = "metric"       // 被控 → 主控:监控数据
	MsgTypePing        = "ping"         // 双向心跳
	MsgTypePong        = "pong"         // 双向心跳响应
	MsgTypeReconfig    = "reconfig"     // 主控 → 被控:重新加载配置
	MsgTypeUninstall   = "uninstall"    // 主控 → 被控:卸载自己
	MsgTypeMigration   = "migration"    // 主控 → 被控:下发迁移种子(MVP 暂不实现)
	MsgTypeError       = "error"        // 通用错误响应
)

// Envelope 是所有 WS 消息的统一外层
type Envelope struct {
	Type    string `json:"type"`
	Payload any    `json:"payload,omitempty"`
}

// HelloPayload 被控首次连接时上报的元信息
type HelloPayload struct {
	Token           string `json:"token"`
	AutoDiscoveryKey string `json:"ad_key,omitempty"`
	Hostname        string `json:"hostname"`
	OS              string `json:"os"`        // linux/windows/darwin
	Platform        string `json:"platform"`  // ubuntu/debian/centos...
	PlatformVer     string `json:"platform_version"`
	KernelVersion   string `json:"kernel"`
	Arch            string `json:"arch"`      // amd64/arm64
	CPUModel        string `json:"cpu_model"`
	CPUCores        int    `json:"cpu_cores"`
	MemTotal        uint64 `json:"mem_total"`
	DiskTotal       uint64 `json:"disk_total"`
	AgentVersion    string `json:"agent_version"`
	BootTime        int64  `json:"boot_time"`
}

// HelloAckPayload 主控接受连接后下发
type HelloAckPayload struct {
	NodeID       int64  `json:"node_id"`
	NodeName     string `json:"node_name"`
	Interval     int    `json:"interval"`     // 采集间隔秒
	HeartbeatSec int    `json:"heartbeat"`    // 心跳间隔秒
}

// MetricPayload 被控上报的监控数据
type MetricPayload struct {
	Timestamp int64 `json:"t"`

	// CPU
	CPUUsage  float64   `json:"cpu"`
	CPUPerCore []float64 `json:"cpu_per,omitempty"`
	Load1     float64   `json:"load1"`
	Load5     float64   `json:"load5"`
	Load15    float64   `json:"load15"`

	// 内存
	MemUsed  uint64 `json:"mem_u"`
	MemTotal uint64 `json:"mem_t"`
	SwapUsed uint64 `json:"swap_u"`
	SwapTotal uint64 `json:"swap_t"`

	// 磁盘
	Disks []DiskInfo `json:"disks"`

	// 网络(增量)
	NetInDelta  uint64 `json:"net_in_d"`  // 自上次上报以来的入站字节数
	NetOutDelta uint64 `json:"net_out_d"` // 出站
	NetInSpeed  uint64 `json:"net_in_s"`  // 当前速率(字节/秒)
	NetOutSpeed uint64 `json:"net_out_s"`

	// 其他
	ProcessCount int    `json:"proc"`
	TCPConn      int    `json:"tcp"`
	UDPConn      int    `json:"udp"`
	Uptime       uint64 `json:"uptime"`
}

type DiskInfo struct {
	Mountpoint string `json:"mp"`
	Used       uint64 `json:"u"`
	Total      uint64 `json:"t"`
}

// ReconfigPayload 主控下发的配置变更
type ReconfigPayload struct {
	Interval     int `json:"interval,omitempty"`
	HeartbeatSec int `json:"heartbeat,omitempty"`
}

// ErrorPayload 错误信息
type ErrorPayload struct {
	Code    string `json:"code"`
	Message string `json:"message"`
}
