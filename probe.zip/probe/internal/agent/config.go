package agent

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sync"
)

const DefaultConfigPath = "/etc/bk/config.json"

type Config struct {
	Server       string `json:"server"`        // wss://panel.example.com
	Token        string `json:"token"`         // 节点 Token,留空则用 AutoDiscovery
	AutoDiscovery string `json:"auto_discovery,omitempty"`
	Interval     int    `json:"interval"`      // 采集间隔秒,默认 2
	Heartbeat    int    `json:"heartbeat"`     // 心跳秒,默认 30
	NICInclude   string `json:"nic_include,omitempty"`
	NICExclude   string `json:"nic_exclude,omitempty"`

	path string
	mu   sync.Mutex
}

func LoadConfig(path string) (*Config, error) {
	if path == "" {
		path = DefaultConfigPath
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	c := &Config{}
	if err := json.Unmarshal(data, c); err != nil {
		return nil, err
	}
	c.path = path
	c.applyDefaults()
	return c, nil
}

func NewConfig(path, server, token, adKey string) *Config {
	c := &Config{
		Server:        server,
		Token:         token,
		AutoDiscovery: adKey,
		path:          path,
	}
	c.applyDefaults()
	return c
}

func (c *Config) applyDefaults() {
	if c.Interval <= 0 {
		c.Interval = 2
	}
	if c.Heartbeat <= 0 {
		c.Heartbeat = 30
	}
	if c.NICExclude == "" {
		c.NICExclude = `^(lo|docker|veth|br-|tun|tap|wg|cni|flannel)`
	}
}

func (c *Config) Save() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.path == "" {
		return errors.New("config path empty")
	}
	if err := os.MkdirAll(filepath.Dir(c.path), 0755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(c.path, data, 0600)
}

func (c *Config) Validate() error {
	if c.Server == "" {
		return errors.New("server URL is empty")
	}
	if c.Token == "" && c.AutoDiscovery == "" {
		return errors.New("either token or auto_discovery key is required")
	}
	return nil
}
