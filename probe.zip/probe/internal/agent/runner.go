package agent

import (
	"context"
	"encoding/json"
	"log"
	"math/rand"
	"net/http"
	"sync"
	"time"

	"github.com/gorilla/websocket"

	"probe/internal/shared"
)

// Run 阻塞运行 Agent 主循环
func Run(cfg *Config) error {
	if err := cfg.Validate(); err != nil {
		return err
	}
	collector := NewCollector(cfg)
	failCount := 0

	for {
		err := runOnce(cfg, collector)
		if err != nil {
			log.Printf("connection error: %v", err)
		}
		failCount++
		// 失败超过阈值,进入低频重试(每小时一次),不爆 CPU
		var wait time.Duration
		if failCount > 1000 {
			wait = time.Hour
		} else {
			wait = backoff(failCount)
		}
		log.Printf("retry in %v (fail #%d)", wait, failCount)
		time.Sleep(wait)
	}
}

func backoff(n int) time.Duration {
	base := time.Second * time.Duration(1<<min(n, 6)) // 1,2,4,8,16,32,64
	if base > 5*time.Minute {
		base = 5 * time.Minute
	}
	maxJitter := int64(base / 4)
	if maxJitter <= 0 {
		return base
	}
	jitter := time.Duration(rand.Int63n(maxJitter))
	return base + jitter
}

// runOnce 建立一次 WS 连接并跑完它的生命周期
func runOnce(cfg *Config, collector *Collector) error {
	dialer := websocket.Dialer{
		HandshakeTimeout: 15 * time.Second,
	}
	header := http.Header{}
	header.Set("User-Agent", "bk-agent/"+shared.Version)

	log.Printf("connecting to %s", cfg.Server)
	conn, _, err := dialer.Dial(cfg.Server+"/ws/agent", header)
	if err != nil {
		return err
	}
	defer conn.Close()

	// 发 hello
	hello := CollectHello(cfg)
	if err := writeJSON(conn, shared.MsgTypeHello, hello); err != nil {
		return err
	}

	// 等 hello_ack
	conn.SetReadDeadline(time.Now().Add(30 * time.Second))
	_, raw, err := conn.ReadMessage()
	if err != nil {
		return err
	}
	var env shared.Envelope
	if err := json.Unmarshal(raw, &env); err != nil {
		return err
	}
	if env.Type != shared.MsgTypeHelloAck {
		return logErr("expected hello_ack, got %s", env.Type)
	}

	// 解析 hello_ack payload
	var ack shared.HelloAckPayload
	if b, err := json.Marshal(env.Payload); err == nil {
		json.Unmarshal(b, &ack)
	}
	interval := ack.Interval
	if interval <= 0 {
		interval = cfg.Interval
	}
	heartbeat := ack.HeartbeatSec
	if heartbeat <= 0 {
		heartbeat = cfg.Heartbeat
	}
	log.Printf("connected as node #%d (%s), interval=%ds, heartbeat=%ds",
		ack.NodeID, ack.NodeName, interval, heartbeat)

	// 准备并发循环
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var wg sync.WaitGroup
	writeMu := &sync.Mutex{}

	// 采集协程
	wg.Add(1)
	go func() {
		defer wg.Done()
		ticker := time.NewTicker(time.Duration(interval) * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				m := collector.Collect()
				if err := writeJSONSafe(writeMu, conn, shared.MsgTypeMetric, m); err != nil {
					log.Printf("write metric error: %v", err)
					cancel()
					return
				}
			}
		}
	}()

	// 心跳协程
	wg.Add(1)
	go func() {
		defer wg.Done()
		ticker := time.NewTicker(time.Duration(heartbeat) * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				if err := writeJSONSafe(writeMu, conn, shared.MsgTypePing, nil); err != nil {
					cancel()
					return
				}
			}
		}
	}()

	// 读循环
	conn.SetReadDeadline(time.Time{})
	for {
		_, raw, err := conn.ReadMessage()
		if err != nil {
			cancel()
			wg.Wait()
			return err
		}
		var e shared.Envelope
		if err := json.Unmarshal(raw, &e); err != nil {
			continue
		}
		switch e.Type {
		case shared.MsgTypePong, shared.MsgTypePing:
			// 心跳响应,主控也可能主动 ping
			if e.Type == shared.MsgTypePing {
				_ = writeJSONSafe(writeMu, conn, shared.MsgTypePong, nil)
			}
		case shared.MsgTypeReconfig:
			handleReconfig(e.Payload, &interval, &heartbeat)
		case shared.MsgTypeUninstall:
			log.Println("received uninstall command, executing...")
			triggerUninstall()
			cancel()
			wg.Wait()
			return nil
		}
	}
}

func handleReconfig(payload any, interval, heartbeat *int) {
	var rc shared.ReconfigPayload
	if b, err := json.Marshal(payload); err == nil {
		json.Unmarshal(b, &rc)
	}
	if rc.Interval > 0 {
		*interval = rc.Interval
		log.Printf("reconfig: interval=%ds", rc.Interval)
	}
	if rc.HeartbeatSec > 0 {
		*heartbeat = rc.HeartbeatSec
	}
	// MVP:不重启采集协程,仅记录(下次连接生效);完整版要重启 ticker
}

func writeJSON(conn *websocket.Conn, msgType string, payload any) error {
	env := shared.Envelope{Type: msgType, Payload: payload}
	return conn.WriteJSON(env)
}

func writeJSONSafe(mu *sync.Mutex, conn *websocket.Conn, msgType string, payload any) error {
	mu.Lock()
	defer mu.Unlock()
	conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	return writeJSON(conn, msgType, payload)
}

type errString string

func (e errString) Error() string { return string(e) }

func logErr(format string, args ...any) error {
	log.Printf(format, args...)
	return errString("protocol error")
}
