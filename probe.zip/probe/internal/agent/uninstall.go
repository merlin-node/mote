package agent

import (
	"log"
	"os"
	"os/exec"
)

// UninstallScript fork 出一个 shell 脚本完成自毁
const UninstallScript = `#!/bin/bash
sleep 2
systemctl stop bk 2>/dev/null || true
systemctl disable bk 2>/dev/null || true
rm -f /etc/systemd/system/bk.service
systemctl daemon-reload 2>/dev/null || true
rm -rf /etc/bk /var/log/bk /opt/bk
rm -f /usr/local/bin/bk
rm -- "$0"
`

// triggerUninstall 在收到主控的卸载指令后,把脚本写到 /tmp 并 fork 执行
func triggerUninstall() {
	scriptPath := "/tmp/bk-uninstall.sh"
	if err := os.WriteFile(scriptPath, []byte(UninstallScript), 0700); err != nil {
		log.Printf("write uninstall script failed: %v", err)
		return
	}
	cmd := exec.Command("/bin/bash", scriptPath)
	cmd.Stdout = nil
	cmd.Stderr = nil
	if err := cmd.Start(); err != nil {
		log.Printf("start uninstall script failed: %v", err)
		return
	}
	log.Println("uninstall script forked, exiting agent")
	os.Exit(0)
}

// DoLocalUninstall 是 `bk uninstall` CLI 命令的实现:同步执行卸载
func DoLocalUninstall() error {
	// 先停服务(忽略错误,可能没用 systemd)
	exec.Command("systemctl", "stop", "bk").Run()
	exec.Command("systemctl", "disable", "bk").Run()

	// 删 unit 文件
	os.Remove("/etc/systemd/system/bk.service")
	exec.Command("systemctl", "daemon-reload").Run()

	// 删数据与配置
	os.RemoveAll("/etc/bk")
	os.RemoveAll("/var/log/bk")
	os.RemoveAll("/opt/bk")

	return nil
}
