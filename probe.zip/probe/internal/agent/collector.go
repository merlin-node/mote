package agent

import (
	"regexp"
	"runtime"
	"strings"
	"time"

	"github.com/shirou/gopsutil/v3/cpu"
	"github.com/shirou/gopsutil/v3/disk"
	"github.com/shirou/gopsutil/v3/host"
	"github.com/shirou/gopsutil/v3/load"
	"github.com/shirou/gopsutil/v3/mem"
	"github.com/shirou/gopsutil/v3/net"
	"github.com/shirou/gopsutil/v3/process"

	"probe/internal/shared"
)

// CollectHello 采集一次性的主机信息(连接时发送)
func CollectHello(cfg *Config) *shared.HelloPayload {
	h := &shared.HelloPayload{
		AgentVersion: shared.Version,
		OS:           runtime.GOOS,
		Arch:         runtime.GOARCH,
	}
	if cfg.Token != "" {
		h.Token = cfg.Token
	}
	if cfg.AutoDiscovery != "" {
		h.AutoDiscoveryKey = cfg.AutoDiscovery
	}
	if info, err := host.Info(); err == nil {
		h.Hostname = info.Hostname
		h.Platform = info.Platform
		h.PlatformVer = info.PlatformVersion
		h.KernelVersion = info.KernelVersion
		h.BootTime = int64(info.BootTime)
	}
	if cpus, err := cpu.Info(); err == nil && len(cpus) > 0 {
		h.CPUModel = cpus[0].ModelName
	}
	if cnt, err := cpu.Counts(true); err == nil {
		h.CPUCores = cnt
	}
	if v, err := mem.VirtualMemory(); err == nil {
		h.MemTotal = v.Total
	}
	if parts, err := disk.Partitions(false); err == nil {
		var total uint64
		for _, p := range parts {
			if !isRealFS(p.Fstype) {
				continue
			}
			if u, err := disk.Usage(p.Mountpoint); err == nil {
				total += u.Total
			}
		}
		h.DiskTotal = total
	}
	return h
}

// Collector 维护采集状态(主要是网络字节数 last 值)
type Collector struct {
	cfg          *Config
	nicIncRegex  *regexp.Regexp
	nicExcRegex  *regexp.Regexp
	lastNetIn    uint64
	lastNetOut   uint64
	lastNetTime  time.Time
	initialized  bool
}

func NewCollector(cfg *Config) *Collector {
	c := &Collector{cfg: cfg}
	if cfg.NICInclude != "" {
		c.nicIncRegex = regexp.MustCompile(cfg.NICInclude)
	}
	if cfg.NICExclude != "" {
		c.nicExcRegex = regexp.MustCompile(cfg.NICExclude)
	}
	return c
}

// Collect 采集一次指标
func (c *Collector) Collect() *shared.MetricPayload {
	now := time.Now()
	m := &shared.MetricPayload{
		Timestamp: now.Unix(),
	}

	// CPU 整体
	if pcts, err := cpu.Percent(0, false); err == nil && len(pcts) > 0 {
		m.CPUUsage = round2(pcts[0])
	}
	// CPU 每核(可选,体积大)
	if pcts, err := cpu.Percent(0, true); err == nil {
		m.CPUPerCore = make([]float64, len(pcts))
		for i, p := range pcts {
			m.CPUPerCore[i] = round2(p)
		}
	}

	// 负载
	if l, err := load.Avg(); err == nil {
		m.Load1 = round2(l.Load1)
		m.Load5 = round2(l.Load5)
		m.Load15 = round2(l.Load15)
	}

	// 内存
	if v, err := mem.VirtualMemory(); err == nil {
		m.MemUsed = v.Used
		m.MemTotal = v.Total
	}
	if s, err := mem.SwapMemory(); err == nil {
		m.SwapUsed = s.Used
		m.SwapTotal = s.Total
	}

	// 磁盘
	if parts, err := disk.Partitions(false); err == nil {
		for _, p := range parts {
			if !isRealFS(p.Fstype) {
				continue
			}
			if u, err := disk.Usage(p.Mountpoint); err == nil && u.Total > 0 {
				m.Disks = append(m.Disks, shared.DiskInfo{
					Mountpoint: p.Mountpoint,
					Used:       u.Used,
					Total:      u.Total,
				})
			}
		}
	}

	// 网络:累加过滤后的网卡
	var inBytes, outBytes uint64
	if stats, err := net.IOCounters(true); err == nil {
		for _, s := range stats {
			if !c.shouldIncludeNIC(s.Name) {
				continue
			}
			inBytes += s.BytesRecv
			outBytes += s.BytesSent
		}
	}

	if c.initialized {
		// 增量 + 速率(防回绕)
		dt := now.Sub(c.lastNetTime).Seconds()
		if dt <= 0 {
			dt = 1
		}
		dIn := safeDelta(inBytes, c.lastNetIn)
		dOut := safeDelta(outBytes, c.lastNetOut)
		m.NetInDelta = dIn
		m.NetOutDelta = dOut
		m.NetInSpeed = uint64(float64(dIn) / dt)
		m.NetOutSpeed = uint64(float64(dOut) / dt)
	}
	c.lastNetIn = inBytes
	c.lastNetOut = outBytes
	c.lastNetTime = now
	c.initialized = true

	// 进程数 + 连接数
	if pids, err := process.Pids(); err == nil {
		m.ProcessCount = len(pids)
	}
	if conns, err := net.Connections("tcp"); err == nil {
		m.TCPConn = len(conns)
	}
	if conns, err := net.Connections("udp"); err == nil {
		m.UDPConn = len(conns)
	}

	// 运行时长
	if bt, err := host.BootTime(); err == nil {
		m.Uptime = uint64(now.Unix()) - bt
	}

	return m
}

func (c *Collector) shouldIncludeNIC(name string) bool {
	// 黑名单优先
	if c.nicExcRegex != nil && c.nicExcRegex.MatchString(name) {
		return false
	}
	// 白名单(如果配了)
	if c.nicIncRegex != nil {
		return c.nicIncRegex.MatchString(name)
	}
	return true
}

func isRealFS(fstype string) bool {
	fstype = strings.ToLower(fstype)
	bad := []string{"tmpfs", "devtmpfs", "proc", "sysfs", "cgroup", "cgroup2",
		"overlay", "squashfs", "fusectl", "debugfs", "tracefs", "configfs",
		"securityfs", "pstore", "bpf", "ramfs", "autofs", "mqueue", "hugetlbfs",
		"nsfs", "rpc_pipefs"}
	for _, b := range bad {
		if fstype == b {
			return false
		}
	}
	return fstype != ""
}

// safeDelta 计算增量,处理 counter 回绕(网卡重置)
func safeDelta(cur, last uint64) uint64 {
	if cur < last {
		return 0 // 回绕了,跳过这次
	}
	d := cur - last
	// 防异常:超过 10GB/秒 视为异常跳过
	if d > 10*1024*1024*1024 {
		return 0
	}
	return d
}

func round2(f float64) float64 {
	return float64(int(f*100)) / 100
}
