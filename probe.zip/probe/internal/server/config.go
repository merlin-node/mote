package server

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
)

const (
	DefaultConfigPath = "/etc/zk/config.json"
	DefaultDataDir    = "/var/lib/zk"
)

type Config struct {
	Listen          string `json:"listen"`           // :25774
	DataDir         string `json:"data_dir"`         // /var/lib/zk
	AdminUsername   string `json:"admin_username"`   // admin
	AdminPassword   string `json:"admin_password"`   // 初始密码,登录后可改
	AutoDiscoveryKey string `json:"auto_discovery_key,omitempty"`
	PublicEnabled   bool   `json:"public_enabled"`   // 公开页是否开放
	MainCurrency    string `json:"main_currency"`    // CNY/USD,展示汇总用
}

func LoadOrCreateConfig(path string) (*Config, error) {
	if path == "" {
		path = DefaultConfigPath
	}
	if data, err := os.ReadFile(path); err == nil {
		c := &Config{}
		if err := json.Unmarshal(data, c); err != nil {
			return nil, err
		}
		c.applyDefaults()
		return c, nil
	}
	// 首次启动:创建默认
	c := &Config{}
	c.applyDefaults()
	c.AdminPassword = randomString(12)
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		return nil, err
	}
	data, _ := json.MarshalIndent(c, "", "  ")
	if err := os.WriteFile(path, data, 0600); err != nil {
		return nil, err
	}
	return c, nil
}

func (c *Config) applyDefaults() {
	if c.Listen == "" {
		c.Listen = ":25774"
	}
	if c.DataDir == "" {
		c.DataDir = DefaultDataDir
	}
	if c.AdminUsername == "" {
		c.AdminUsername = "admin"
	}
	if c.MainCurrency == "" {
		c.MainCurrency = "USD"
	}
}

func (c *Config) DBPath() string {
	return filepath.Join(c.DataDir, "data.db")
}

func (c *Config) Validate() error {
	if c.AdminPassword == "" {
		return errors.New("admin_password is empty")
	}
	return nil
}

// randomString 生成可读的随机密码
func randomString(n int) string {
	const charset = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	b := make([]byte, n)
	for i := range b {
		b[i] = charset[secureRand(len(charset))]
	}
	return string(b)
}
