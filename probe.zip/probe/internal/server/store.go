package server

import (
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"sync"
	"time"

	_ "modernc.org/sqlite"
)

type Store struct {
	db *sql.DB
	mu sync.Mutex
}

func OpenStore(path string) (*Store, error) {
	db, err := sql.Open("sqlite", path+"?_pragma=journal_mode(WAL)&_pragma=busy_timeout(5000)")
	if err != nil {
		return nil, err
	}
	s := &Store{db: db}
	if err := s.migrate(); err != nil {
		return nil, err
	}
	return s, nil
}

func (s *Store) Close() error { return s.db.Close() }

func (s *Store) migrate() error {
	stmts := []string{
		`CREATE TABLE IF NOT EXISTS nodes (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			token TEXT UNIQUE NOT NULL,
			group_name TEXT DEFAULT '',
			tags TEXT DEFAULT '[]',
			os TEXT DEFAULT '',
			platform TEXT DEFAULT '',
			arch TEXT DEFAULT '',
			cpu_model TEXT DEFAULT '',
			cpu_cores INTEGER DEFAULT 0,
			mem_total INTEGER DEFAULT 0,
			disk_total INTEGER DEFAULT 0,
			agent_version TEXT DEFAULT '',
			boot_time INTEGER DEFAULT 0,
			created_at INTEGER NOT NULL,
			last_seen INTEGER DEFAULT 0,
			deleted_at INTEGER DEFAULT 0
		)`,
		`CREATE TABLE IF NOT EXISTS node_meta (
			node_id INTEGER PRIMARY KEY,
			note TEXT DEFAULT '',
			note_visible INTEGER DEFAULT 1,
			price REAL DEFAULT 0,
			currency TEXT DEFAULT 'USD',
			cycle TEXT DEFAULT 'monthly',
			start_date INTEGER DEFAULT 0,
			next_due INTEGER DEFAULT 0,
			auto_renew INTEGER DEFAULT 1,
			traffic_limit INTEGER DEFAULT 0,
			traffic_type TEXT DEFAULT 'sum',
			traffic_reset_day INTEGER DEFAULT 1,
			traffic_reset_tz TEXT DEFAULT 'Asia/Shanghai',
			traffic_used_in INTEGER DEFAULT 0,
			traffic_used_out INTEGER DEFAULT 0,
			traffic_period_start INTEGER DEFAULT 0
		)`,
		`CREATE TABLE IF NOT EXISTS metrics (
			node_id INTEGER NOT NULL,
			ts INTEGER NOT NULL,
			data BLOB NOT NULL,
			PRIMARY KEY (node_id, ts)
		)`,
		`CREATE INDEX IF NOT EXISTS idx_metrics_ts ON metrics(ts)`,
		`CREATE TABLE IF NOT EXISTS traffic_history (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			node_id INTEGER NOT NULL,
			period_start INTEGER NOT NULL,
			period_end INTEGER NOT NULL,
			used_in INTEGER NOT NULL,
			used_out INTEGER NOT NULL
		)`,
	}
	for _, q := range stmts {
		if _, err := s.db.Exec(q); err != nil {
			return fmt.Errorf("migrate: %w", err)
		}
	}
	return nil
}

// === Nodes ===

type Node struct {
	ID           int64  `json:"id"`
	Name         string `json:"name"`
	Token        string `json:"token,omitempty"`
	GroupName    string `json:"group"`
	Tags         []string `json:"tags"`
	OS           string `json:"os"`
	Platform     string `json:"platform"`
	Arch         string `json:"arch"`
	CPUModel     string `json:"cpu_model"`
	CPUCores     int    `json:"cpu_cores"`
	MemTotal     uint64 `json:"mem_total"`
	DiskTotal    uint64 `json:"disk_total"`
	AgentVersion string `json:"agent_version"`
	BootTime     int64  `json:"boot_time"`
	CreatedAt    int64  `json:"created_at"`
	LastSeen     int64  `json:"last_seen"`
}

func (s *Store) CreateNode(name string) (*Node, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	token := generateToken()
	res, err := s.db.Exec(
		`INSERT INTO nodes(name, token, created_at) VALUES(?, ?, ?)`,
		name, token, time.Now().Unix())
	if err != nil {
		return nil, err
	}
	id, _ := res.LastInsertId()
	// 同时创建 meta 行
	s.db.Exec(`INSERT INTO node_meta(node_id) VALUES(?)`, id)
	return s.GetNode(id)
}

func (s *Store) GetNode(id int64) (*Node, error) {
	row := s.db.QueryRow(`SELECT id, name, token, group_name, tags, os, platform, arch,
		cpu_model, cpu_cores, mem_total, disk_total, agent_version, boot_time, created_at, last_seen
		FROM nodes WHERE id=? AND deleted_at=0`, id)
	return scanNode(row)
}

func (s *Store) GetNodeByToken(token string) (*Node, error) {
	row := s.db.QueryRow(`SELECT id, name, token, group_name, tags, os, platform, arch,
		cpu_model, cpu_cores, mem_total, disk_total, agent_version, boot_time, created_at, last_seen
		FROM nodes WHERE token=? AND deleted_at=0`, token)
	return scanNode(row)
}

func (s *Store) ListNodes() ([]*Node, error) {
	rows, err := s.db.Query(`SELECT id, name, token, group_name, tags, os, platform, arch,
		cpu_model, cpu_cores, mem_total, disk_total, agent_version, boot_time, created_at, last_seen
		FROM nodes WHERE deleted_at=0 ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*Node
	for rows.Next() {
		n, err := scanNode(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, n)
	}
	return out, nil
}

func (s *Store) UpdateNodeName(id int64, name string) error {
	_, err := s.db.Exec(`UPDATE nodes SET name=? WHERE id=?`, name, id)
	return err
}

// UpdateNodeInfo 由 hello 触发更新静态信息
func (s *Store) UpdateNodeInfo(id int64, os_, platform, arch, cpuModel string,
	cpuCores int, memTotal, diskTotal uint64, agentVer string, bootTime int64) error {
	_, err := s.db.Exec(`UPDATE nodes SET os=?, platform=?, arch=?, cpu_model=?,
		cpu_cores=?, mem_total=?, disk_total=?, agent_version=?, boot_time=?
		WHERE id=?`, os_, platform, arch, cpuModel, cpuCores, memTotal, diskTotal,
		agentVer, bootTime, id)
	return err
}

func (s *Store) UpdateLastSeen(id int64, ts int64) error {
	_, err := s.db.Exec(`UPDATE nodes SET last_seen=? WHERE id=?`, ts, id)
	return err
}

func (s *Store) DeleteNode(id int64) error {
	_, err := s.db.Exec(`UPDATE nodes SET deleted_at=? WHERE id=?`, time.Now().Unix(), id)
	return err
}

func scanNode(row interface{ Scan(...any) error }) (*Node, error) {
	var n Node
	var tagsJSON string
	err := row.Scan(&n.ID, &n.Name, &n.Token, &n.GroupName, &tagsJSON,
		&n.OS, &n.Platform, &n.Arch, &n.CPUModel, &n.CPUCores,
		&n.MemTotal, &n.DiskTotal, &n.AgentVersion, &n.BootTime,
		&n.CreatedAt, &n.LastSeen)
	if err != nil {
		return nil, err
	}
	if tagsJSON != "" {
		json.Unmarshal([]byte(tagsJSON), &n.Tags)
	}
	if n.Tags == nil {
		n.Tags = []string{}
	}
	return &n, nil
}

// === Meta ===

type NodeMeta struct {
	NodeID             int64   `json:"node_id"`
	Note               string  `json:"note"`
	NoteVisible        bool    `json:"note_visible"`
	Price              float64 `json:"price"`
	Currency           string  `json:"currency"`
	Cycle              string  `json:"cycle"`
	StartDate          int64   `json:"start_date"`
	NextDue            int64   `json:"next_due"`
	AutoRenew          bool    `json:"auto_renew"`
	TrafficLimit       uint64  `json:"traffic_limit"`
	TrafficType        string  `json:"traffic_type"`
	TrafficResetDay    int     `json:"traffic_reset_day"`
	TrafficResetTZ     string  `json:"traffic_reset_tz"`
	TrafficUsedIn      uint64  `json:"traffic_used_in"`
	TrafficUsedOut     uint64  `json:"traffic_used_out"`
	TrafficPeriodStart int64   `json:"traffic_period_start"`
}

func (s *Store) GetMeta(nodeID int64) (*NodeMeta, error) {
	row := s.db.QueryRow(`SELECT node_id, note, note_visible, price, currency, cycle,
		start_date, next_due, auto_renew, traffic_limit, traffic_type, traffic_reset_day,
		traffic_reset_tz, traffic_used_in, traffic_used_out, traffic_period_start
		FROM node_meta WHERE node_id=?`, nodeID)
	var m NodeMeta
	var nv, ar int
	err := row.Scan(&m.NodeID, &m.Note, &nv, &m.Price, &m.Currency, &m.Cycle,
		&m.StartDate, &m.NextDue, &ar, &m.TrafficLimit, &m.TrafficType,
		&m.TrafficResetDay, &m.TrafficResetTZ, &m.TrafficUsedIn,
		&m.TrafficUsedOut, &m.TrafficPeriodStart)
	if err != nil {
		return nil, err
	}
	m.NoteVisible = nv != 0
	m.AutoRenew = ar != 0
	return &m, nil
}

func (s *Store) UpdateMeta(m *NodeMeta) error {
	_, err := s.db.Exec(`UPDATE node_meta SET note=?, note_visible=?, price=?,
		currency=?, cycle=?, start_date=?, next_due=?, auto_renew=?,
		traffic_limit=?, traffic_type=?, traffic_reset_day=?, traffic_reset_tz=?
		WHERE node_id=?`,
		m.Note, boolToInt(m.NoteVisible), m.Price, m.Currency, m.Cycle,
		m.StartDate, m.NextDue, boolToInt(m.AutoRenew),
		m.TrafficLimit, m.TrafficType, m.TrafficResetDay, m.TrafficResetTZ,
		m.NodeID)
	return err
}

// AddTraffic 累加流量(由 metric 上报触发)
func (s *Store) AddTraffic(nodeID int64, deltaIn, deltaOut uint64) error {
	_, err := s.db.Exec(`UPDATE node_meta
		SET traffic_used_in = traffic_used_in + ?,
		    traffic_used_out = traffic_used_out + ?
		WHERE node_id=?`, deltaIn, deltaOut, nodeID)
	return err
}

// ResetTraffic 周期重置(归档历史 + 清零)
func (s *Store) ResetTraffic(nodeID int64, periodStart, periodEnd int64) error {
	m, err := s.GetMeta(nodeID)
	if err != nil {
		return err
	}
	if m.TrafficUsedIn > 0 || m.TrafficUsedOut > 0 {
		_, err := s.db.Exec(`INSERT INTO traffic_history(node_id, period_start, period_end, used_in, used_out)
			VALUES(?,?,?,?,?)`, nodeID, m.TrafficPeriodStart, periodEnd, m.TrafficUsedIn, m.TrafficUsedOut)
		if err != nil {
			return err
		}
	}
	_, err = s.db.Exec(`UPDATE node_meta SET traffic_used_in=0, traffic_used_out=0,
		traffic_period_start=? WHERE node_id=?`, periodStart, nodeID)
	return err
}

// === Metrics ===

func (s *Store) SaveMetric(nodeID int64, ts int64, data []byte) error {
	_, err := s.db.Exec(`INSERT OR REPLACE INTO metrics(node_id, ts, data) VALUES(?,?,?)`,
		nodeID, ts, data)
	return err
}

// GetLatestMetric 返回某节点最新的指标 JSON
func (s *Store) GetLatestMetric(nodeID int64) ([]byte, int64, error) {
	row := s.db.QueryRow(`SELECT data, ts FROM metrics WHERE node_id=? ORDER BY ts DESC LIMIT 1`, nodeID)
	var data []byte
	var ts int64
	err := row.Scan(&data, &ts)
	return data, ts, err
}

// CleanupOldMetrics 删除指定时间之前的 metrics
func (s *Store) CleanupOldMetrics(before int64) error {
	_, err := s.db.Exec(`DELETE FROM metrics WHERE ts < ?`, before)
	return err
}

// === Helpers ===

func generateToken() string {
	b := make([]byte, 16)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func secureRand(max int) int {
	n, err := rand.Int(rand.Reader, big.NewInt(int64(max)))
	if err != nil {
		return 0
	}
	return int(n.Int64())
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

var ErrNotFound = errors.New("not found")
