package server

import (
	"encoding/json"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/gorilla/websocket"

	"probe/internal/shared"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  4096,
	WriteBufferSize: 4096,
	CheckOrigin:     func(r *http.Request) bool { return true },
}

// Hub 维护所有在线 Agent 连接
type Hub struct {
	store *Store
	cfg   *Config
	mu    sync.RWMutex
	conns map[int64]*AgentConn // nodeID → conn
}

type AgentConn struct {
	NodeID    int64
	conn      *websocket.Conn
	writeMu   sync.Mutex
	send      chan []byte
	closeOnce sync.Once
	closed    chan struct{}
	hub       *Hub
}

func NewHub(store *Store, cfg *Config) *Hub {
	return &Hub{
		store: store,
		cfg:   cfg,
		conns: make(map[int64]*AgentConn),
	}
}

// HandleWS 是 /ws/agent 的 HTTP handler
func (h *Hub) HandleWS(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Println("ws upgrade:", err)
		return
	}

	// 等 hello
	conn.SetReadDeadline(time.Now().Add(30 * time.Second))
	_, raw, err := conn.ReadMessage()
	if err != nil {
		conn.Close()
		return
	}
	var env shared.Envelope
	if err := json.Unmarshal(raw, &env); err != nil {
		conn.Close()
		return
	}
	if env.Type != shared.MsgTypeHello {
		conn.Close()
		return
	}
	var hello shared.HelloPayload
	if b, _ := json.Marshal(env.Payload); b != nil {
		json.Unmarshal(b, &hello)
	}

	// 鉴权:Token 或 AutoDiscovery
	var node *Node
	if hello.Token != "" {
		node, err = h.store.GetNodeByToken(hello.Token)
		if err != nil {
			log.Printf("ws: unknown token from %s", r.RemoteAddr)
			conn.Close()
			return
		}
	} else if hello.AutoDiscoveryKey != "" && hello.AutoDiscoveryKey == h.cfg.AutoDiscoveryKey {
		// 自动注册新节点
		name := hello.Hostname
		if name == "" {
			name = "unnamed"
		}
		node, err = h.store.CreateNode(name)
		if err != nil {
			log.Println("auto-create node failed:", err)
			conn.Close()
			return
		}
		log.Printf("auto-registered node #%d %q from %s", node.ID, name, r.RemoteAddr)
	} else {
		log.Printf("ws: auth failed from %s", r.RemoteAddr)
		conn.Close()
		return
	}

	// 更新节点静态信息
	h.store.UpdateNodeInfo(node.ID,
		hello.OS, hello.Platform, hello.Arch, hello.CPUModel,
		hello.CPUCores, hello.MemTotal, hello.DiskTotal,
		hello.AgentVersion, hello.BootTime)

	// 发 hello_ack
	ack := shared.HelloAckPayload{
		NodeID:       node.ID,
		NodeName:     node.Name,
		Interval:     2,
		HeartbeatSec: 30,
	}
	if err := writeJSON(conn, shared.MsgTypeHelloAck, ack); err != nil {
		conn.Close()
		return
	}

	// 注册到 hub
	ac := &AgentConn{
		NodeID: node.ID,
		conn:   conn,
		send:   make(chan []byte, 64),
		closed: make(chan struct{}),
		hub:    h,
	}
	h.register(ac)
	defer h.unregister(ac)

	log.Printf("agent #%d %q connected from %s", node.ID, node.Name, r.RemoteAddr)

	// 启动 writer 和 reader
	go ac.writer()
	ac.reader()
}

func (h *Hub) register(c *AgentConn) {
	h.mu.Lock()
	defer h.mu.Unlock()
	// 同节点重连,关掉旧的
	if old, ok := h.conns[c.NodeID]; ok {
		old.Close()
	}
	h.conns[c.NodeID] = c
}

func (h *Hub) unregister(c *AgentConn) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if cur, ok := h.conns[c.NodeID]; ok && cur == c {
		delete(h.conns, c.NodeID)
	}
	c.Close()
}

func (h *Hub) IsOnline(nodeID int64) bool {
	h.mu.RLock()
	defer h.mu.RUnlock()
	_, ok := h.conns[nodeID]
	return ok
}

func (h *Hub) OnlineNodes() []int64 {
	h.mu.RLock()
	defer h.mu.RUnlock()
	out := make([]int64, 0, len(h.conns))
	for id := range h.conns {
		out = append(out, id)
	}
	return out
}

// SendTo 给指定节点发指令
func (h *Hub) SendTo(nodeID int64, msgType string, payload any) error {
	h.mu.RLock()
	c, ok := h.conns[nodeID]
	h.mu.RUnlock()
	if !ok {
		return ErrNotFound
	}
	data, _ := json.Marshal(shared.Envelope{Type: msgType, Payload: payload})
	select {
	case c.send <- data:
		return nil
	default:
		return ErrNotFound // 缓冲满
	}
}

// === AgentConn methods ===

func (c *AgentConn) Close() {
	c.closeOnce.Do(func() {
		close(c.closed)
		c.conn.Close()
	})
}

func (c *AgentConn) reader() {
	defer c.Close()
	for {
		_, raw, err := c.conn.ReadMessage()
		if err != nil {
			return
		}
		var env shared.Envelope
		if err := json.Unmarshal(raw, &env); err != nil {
			continue
		}
		switch env.Type {
		case shared.MsgTypePing:
			c.sendRaw(shared.MsgTypePong, nil)
		case shared.MsgTypePong:
			// 心跳响应,不做处理
		case shared.MsgTypeMetric:
			c.handleMetric(env.Payload)
		}
	}
}

func (c *AgentConn) writer() {
	for {
		select {
		case <-c.closed:
			return
		case msg := <-c.send:
			c.writeMu.Lock()
			c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			err := c.conn.WriteMessage(websocket.TextMessage, msg)
			c.writeMu.Unlock()
			if err != nil {
				c.Close()
				return
			}
		}
	}
}

func (c *AgentConn) sendRaw(msgType string, payload any) {
	data, _ := json.Marshal(shared.Envelope{Type: msgType, Payload: payload})
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	c.conn.WriteMessage(websocket.TextMessage, data)
}

func (c *AgentConn) handleMetric(payload any) {
	var m shared.MetricPayload
	if b, _ := json.Marshal(payload); b != nil {
		json.Unmarshal(b, &m)
	}
	if m.Timestamp == 0 {
		m.Timestamp = time.Now().Unix()
	}
	// 持久化最新指标
	data, _ := json.Marshal(&m)
	c.hub.store.SaveMetric(c.NodeID, m.Timestamp, data)
	c.hub.store.UpdateLastSeen(c.NodeID, m.Timestamp)
	// 累加流量
	if m.NetInDelta > 0 || m.NetOutDelta > 0 {
		c.hub.store.AddTraffic(c.NodeID, m.NetInDelta, m.NetOutDelta)
	}
}

func writeJSON(conn *websocket.Conn, msgType string, payload any) error {
	env := shared.Envelope{Type: msgType, Payload: payload}
	return conn.WriteJSON(env)
}
