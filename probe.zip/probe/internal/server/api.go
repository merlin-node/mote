package server

import (
	"embed"
	"encoding/json"
	"io/fs"
	"net/http"
	"strconv"
	"strings"
	"time"
)

//go:embed web/*
var webFS embed.FS

// API 提供 REST API + 静态文件
type API struct {
	store *Store
	hub   *Hub
	cfg   *Config
}

func NewAPI(store *Store, hub *Hub, cfg *Config) *API {
	return &API{store: store, hub: hub, cfg: cfg}
}

func (a *API) Routes() http.Handler {
	mux := http.NewServeMux()

	// WS
	mux.HandleFunc("/ws/agent", a.hub.HandleWS)

	// API
	mux.HandleFunc("/api/nodes", a.handleNodes)            // GET 列表 / POST 创建
	mux.HandleFunc("/api/nodes/", a.handleNodeOps)         // /api/nodes/{id}, /api/nodes/{id}/meta
	mux.HandleFunc("/api/install-cmd", a.handleInstallCmd) // 生成安装命令
	mux.HandleFunc("/api/config", a.handleConfig)
	mux.HandleFunc("/api/login", a.handleLogin)

	// 静态文件(嵌入的 web 目录)
	subFS, _ := fs.Sub(webFS, "web")
	fileServer := http.FileServer(http.FS(subFS))
	mux.Handle("/", fileServer)

	return basicAuth(a.cfg, mux)
}

// basicAuth 简单 HTTP Basic 鉴权(MVP),只对 /api/ 与首页(非 /ws/agent)生效
func basicAuth(cfg *Config, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// WS 端点跳过(Agent 用自己的 token 鉴权)
		if strings.HasPrefix(r.URL.Path, "/ws/") {
			next.ServeHTTP(w, r)
			return
		}
		// 公开端点(若启用)
		if strings.HasPrefix(r.URL.Path, "/api/public/") {
			next.ServeHTTP(w, r)
			return
		}
		u, p, ok := r.BasicAuth()
		if !ok || u != cfg.AdminUsername || p != cfg.AdminPassword {
			w.Header().Set("WWW-Authenticate", `Basic realm="zk panel"`)
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		next.ServeHTTP(w, r)
	})
}

// === handlers ===

type nodeWithStatus struct {
	*Node
	Meta    *NodeMeta `json:"meta,omitempty"`
	Online  bool      `json:"online"`
	Latest  *json.RawMessage `json:"latest,omitempty"`
}

func (a *API) handleNodes(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		nodes, err := a.store.ListNodes()
		if err != nil {
			httpError(w, err)
			return
		}
		out := make([]*nodeWithStatus, 0, len(nodes))
		for _, n := range nodes {
			ns := &nodeWithStatus{Node: n, Online: a.hub.IsOnline(n.ID)}
			ns.Meta, _ = a.store.GetMeta(n.ID)
			if data, _, err := a.store.GetLatestMetric(n.ID); err == nil {
				raw := json.RawMessage(data)
				ns.Latest = &raw
			}
			out = append(out, ns)
		}
		writeJSONResp(w, out)

	case http.MethodPost:
		var req struct {
			Name string `json:"name"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		if req.Name == "" {
			req.Name = "new-node"
		}
		n, err := a.store.CreateNode(req.Name)
		if err != nil {
			httpError(w, err)
			return
		}
		writeJSONResp(w, n)
	default:
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
	}
}

// /api/nodes/{id}              GET/PATCH/DELETE  节点本体
// /api/nodes/{id}/meta         GET/PATCH         元信息
// /api/nodes/{id}/uninstall    POST              下发卸载
func (a *API) handleNodeOps(w http.ResponseWriter, r *http.Request) {
	path := strings.TrimPrefix(r.URL.Path, "/api/nodes/")
	parts := strings.Split(path, "/")
	if len(parts) == 0 || parts[0] == "" {
		http.NotFound(w, r)
		return
	}
	id, err := strconv.ParseInt(parts[0], 10, 64)
	if err != nil {
		http.NotFound(w, r)
		return
	}

	sub := ""
	if len(parts) >= 2 {
		sub = parts[1]
	}

	switch sub {
	case "":
		a.opNode(w, r, id)
	case "meta":
		a.opMeta(w, r, id)
	case "uninstall":
		a.opUninstall(w, r, id)
	default:
		http.NotFound(w, r)
	}
}

func (a *API) opNode(w http.ResponseWriter, r *http.Request, id int64) {
	switch r.Method {
	case http.MethodGet:
		n, err := a.store.GetNode(id)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		writeJSONResp(w, n)
	case http.MethodPatch:
		var req struct {
			Name *string `json:"name"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		if req.Name != nil {
			a.store.UpdateNodeName(id, *req.Name)
		}
		n, _ := a.store.GetNode(id)
		writeJSONResp(w, n)
	case http.MethodDelete:
		a.store.DeleteNode(id)
		w.WriteHeader(http.StatusNoContent)
	default:
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
	}
}

func (a *API) opMeta(w http.ResponseWriter, r *http.Request, id int64) {
	switch r.Method {
	case http.MethodGet:
		m, err := a.store.GetMeta(id)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		writeJSONResp(w, m)
	case http.MethodPatch, http.MethodPut:
		m, err := a.store.GetMeta(id)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		// 用部分更新:解码到现有结构上
		json.NewDecoder(r.Body).Decode(m)
		m.NodeID = id

		// 如果 cycle/start_date 改了,自动算 next_due
		if m.Cycle != "" && m.StartDate > 0 && m.Cycle != "lifetime" && m.Cycle != "once" {
			m.NextDue = ComputeNextDue(m.StartDate, m.Cycle, time.Now().Unix())
		}

		if err := a.store.UpdateMeta(m); err != nil {
			httpError(w, err)
			return
		}
		writeJSONResp(w, m)
	default:
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
	}
}

func (a *API) opUninstall(w http.ResponseWriter, r *http.Request, id int64) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	err := a.hub.SendTo(id, "uninstall", nil)
	if err != nil {
		http.Error(w, "node offline or not connected", http.StatusBadRequest)
		return
	}
	w.WriteHeader(http.StatusAccepted)
}

func (a *API) handleInstallCmd(w http.ResponseWriter, r *http.Request) {
	tokenStr := r.URL.Query().Get("token")
	server := r.Host
	scheme := "wss"
	if r.TLS == nil {
		scheme = "ws"
	}
	httpScheme := "https"
	if r.TLS == nil {
		httpScheme = "http"
	}
	wsURL := scheme + "://" + server
	httpURL := httpScheme + "://" + server

	linuxCmd := "bash <(curl -fsSL " + httpURL + "/install-bk.sh) -s " + wsURL + " -t " + tokenStr
	out := map[string]string{
		"linux":   linuxCmd,
		"ws_url":  wsURL,
		"token":   tokenStr,
	}
	writeJSONResp(w, out)
}

func (a *API) handleConfig(w http.ResponseWriter, r *http.Request) {
	out := map[string]any{
		"version":            "dev",
		"main_currency":      a.cfg.MainCurrency,
		"auto_discovery_key": a.cfg.AutoDiscoveryKey,
	}
	writeJSONResp(w, out)
}

func (a *API) handleLogin(w http.ResponseWriter, r *http.Request) {
	// 已经被 basicAuth 拦截,能到这里说明通过了
	writeJSONResp(w, map[string]bool{"ok": true})
}

// === helpers ===

func writeJSONResp(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

func httpError(w http.ResponseWriter, err error) {
	http.Error(w, err.Error(), http.StatusInternalServerError)
}
