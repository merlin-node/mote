# probe — 极轻量服务器监控探针

> 主控 `zk` + 被控 `bk`,类似 Komari / 哪吒,但更轻、更顺手

## 特性

- **极轻量**: 被控 Agent 内存 < 5MB,二进制 < 3MB(UPX 压缩后)
- **单二进制**: 无外部依赖,WebSocket 单端口,过 CDN 过反代
- **完整账单**: 月付/季付/年付/长期等周期,多货币,自动算到期日
- **流量管理**: 四种统计模式(双向/取大/单向)、月度重置、时区感知
- **节点备注**: 纯文本多行备注,公开页可隐藏
- **CLI 友好**: `zk` / `bk` 交互菜单,start/stop/restart/status/uninstall 一应俱全
- **远程卸载**: 网页一键下发,被控自动清理

## 项目结构

```
probe/
├── cmd/
│   ├── zk/       主控 CLI
│   └── bk/       被控 CLI
├── internal/
│   ├── shared/   共享协议(WS 消息定义)
│   ├── agent/    被控核心(采集、上报、重连、卸载)
│   └── server/   主控核心(WS Hub、SQLite、REST API、调度器)
│       └── web/  内嵌前端(单文件 HTML)
├── scripts/
│   ├── install-zk.sh   主控一键安装
│   └── install-bk.sh   被控一键安装
└── Makefile
```

## 构建

```bash
# 本地构建(当前平台)
make build

# 交叉编译
make linux-amd64
make linux-arm64

# 一并构建所有发布产物
make release
```

构建产物在 `dist/` 目录。

## 本地开发联调

开两个终端:

```bash
# 终端 1: 启动主控
make run-zk
# 输出形如:
# admin user: admin
# admin pass: aB3kP9q2X7yZ
# zk dev listening on :25774
```

浏览器打开 http://127.0.0.1:25774,Basic Auth 输入上面的用户名密码登录。
点 "+ 添加节点",创建后会得到一个 Token。

```bash
# 终端 2: 启动被控(替换 TOKEN)
./dist/bk run -s ws://127.0.0.1:25774 -t TOKEN_HERE
```

刷新面板,节点应该上线。

## 生产部署

### 主控

在你打算做主控的服务器上:

```bash
# 1. 把 dist/zk-linux-amd64 上传到该服务器,放在某个目录
# 2. 在该目录执行(脚本会优先用本地 ./dist/zk-linux-amd64):
sudo bash scripts/install-zk.sh

# 安装完成后会输出:
#   访问地址 : http://1.2.3.4:25774
#   用户名   : admin
#   密码     : aB3kP9q2X7yZ
```

**强烈建议用域名 + Nginx 反代**,未来迁移只需改 DNS:

```nginx
server {
  listen 443 ssl http2;
  server_name panel.example.com;
  # ssl_certificate ...

  location / {
    proxy_pass http://127.0.0.1:25774;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_read_timeout 86400;
  }
}
```

### 被控

在面板上 "+ 添加节点" 创建节点,得到安装命令:

```bash
bash <(curl -fsSL https://panel.example.com/install-bk.sh) \
  -s wss://panel.example.com -t TOKEN_HERE
```

## CLI 速查

### 主控 `zk`

| 命令 | 作用 |
|---|---|
| `zk` | 打开交互菜单 |
| `zk status` | 查看状态、访问地址 |
| `zk start/stop/restart` | 服务控制 |
| `zk uninstall` | 卸载主控 |
| `zk version` | 版本 |

### 被控 `bk`

| 命令 | 作用 |
|---|---|
| `bk` | 打开交互菜单 |
| `bk status` | 查看连接状态 |
| `bk start/stop/restart` | 服务控制 |
| `bk reconfig` | 修改主控地址/Token |
| `bk uninstall` | 卸载被控 |
| `bk version` | 版本 |

## 配置文件

### 主控 `/etc/zk/config.json`

```json
{
  "listen": ":25774",
  "data_dir": "/var/lib/zk",
  "admin_username": "admin",
  "admin_password": "改这个改密码",
  "auto_discovery_key": "",
  "main_currency": "CNY"
}
```

修改后 `systemctl restart zk` 生效。

### 被控 `/etc/bk/config.json`

```json
{
  "server": "wss://panel.example.com",
  "token": "abcd1234...",
  "auto_discovery": "",
  "interval": 2,
  "heartbeat": 30,
  "nic_include": "",
  "nic_exclude": "^(lo|docker|veth|br-|tun|tap|wg|cni|flannel)"
}
```

修改后 `bk restart` 生效。

## 数据存储

- 主控数据: `/var/lib/zk/data.db` (SQLite)
- 日志: `/var/log/zk/` 和 `/var/log/bk/`
- 备份建议: 定期复制 `data.db` 即可(MVP 暂未内置自动备份)

## 流量统计模式

根据 VPS 商家的计费方式选:

| 模式 | 公式 | 典型场景 |
|---|---|---|
| 双向合计 `sum` | `in + out` | 大部分廉价 VPS |
| 取大单向 `max` | `max(in, out)` | Hetzner 等 |
| 仅出站 `out` | `out` | AWS / GCP |
| 仅入站 `in` | `in` | 极少见 |

## 续费周期

支持月付/季付/半年付/年付/两年付/一次性/长期(终身),月底加月会做边界处理(如 1/31 月付下次是 2/28)。

## 当前 MVP 未实现(参考完整设计文档)

- ❌ 多货币汇率折算(目前按原币显示)
- ❌ 历史曲线 + 降采样(目前只存最新指标)
- ❌ 告警通知(TG / Webhook / Email)
- ❌ 拨测(ICMP / TCP / HTTP)
- ❌ 备份/导入(JSON / S3 / WebDAV)
- ❌ 迁移种子机制(目前只能 `bk reconfig` 兜底)
- ❌ 一键更新 `zk update`
- ❌ 公开页(目前所有访问都要登录)

## 卸载

**主控**: `sudo zk uninstall`(或 `sudo bash` 执行下述)
```bash
sudo systemctl stop zk
sudo systemctl disable zk
sudo rm /etc/systemd/system/zk.service
sudo systemctl daemon-reload
sudo rm -rf /etc/zk /var/lib/zk /var/log/zk /usr/local/bin/zk
```

**被控**: `sudo bk uninstall`

## 许可

MIT
