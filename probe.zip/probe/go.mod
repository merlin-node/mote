module probe

go 1.22

require (
	github.com/gorilla/websocket v1.5.1
	github.com/shirou/gopsutil/v3 v3.24.5
	modernc.org/sqlite v1.29.10
)
